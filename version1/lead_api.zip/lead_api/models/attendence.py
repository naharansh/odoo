# from odoo import models, fields, api
# import secrets

# class ApiToken(models.Model):
#     _name = 'api.token'
#     _description = 'API Token Store'

#     name = fields.Char(string="Token", required=True, readonly=True)
#     valid_until = fields.Datetime(string="Valid Until")

#     @api.model
#     def generate_auto_token(self, hours_valid=24):
#         token = secrets.token_hex(32)  # 64-char random token
#         expiry = fields.Datetime.now() + fields.DateTime.timedelta(hours=hours_valid)
#         return self.create({'name': token, 'valid_until': expiry})
