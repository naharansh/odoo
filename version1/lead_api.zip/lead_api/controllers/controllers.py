# -*- coding: utf-8 -*-
# from odoo import http


# class Attendences(http.Controller):
#     @http.route('/attendences/attendences', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/attendences/attendences/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('attendences.listing', {
#             'root': '/attendences/attendences',
#             'objects': http.request.env['attendences.attendences'].search([]),
#         })

#     @http.route('/attendences/attendences/objects/<model("attendences.attendences"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('attendences.object', {
#             'object': obj
#         })

