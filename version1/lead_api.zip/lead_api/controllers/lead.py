from odoo import http
from odoo.http import request
import json

class LeadsAPI(http.Controller):

    # =========================================================
    # COMMON RESPONSE
    # =========================================================
    def _response(self, data, status=200):
        origin = request.httprequest.headers.get('Origin') or '*'
        return request.make_response(
            json.dumps(data),
            headers=[
                ('Content-Type', 'application/json'),
                ('Access-Control-Allow-Origin', origin),        # ✅ THIS WAS MISSING
                ('Access-Control-Allow-Methods', 'POST, OPTIONS'),
                ('Access-Control-Allow-Headers', 'Origin, Content-Type, Accept, Authorization'),
            ],
            status=status
        )

    # =========================================================
    # CHECK TOKEN
    # =========================================================
    def _check_auth_token(self):
        auth_header = request.httprequest.headers.get('Authorization')
        if not auth_header:
            return False
        if not auth_header.startswith("Bearer "):
            return False
        token = auth_header.replace("Bearer ", "").strip()
        stored_token = request.env[
            'ir.config_parameter'
        ].sudo().get_param('api.auth_token')
        return token == stored_token

    # =========================================================
    # CREATE LEAD API
    # =========================================================
    @http.route(
        '/api/create_lead',
        type='http',
        auth='public',
        methods=['POST', 'OPTIONS'],
        csrf=False,
    )
    def create_lead(self, **kwargs):

        # =====================================================
        # HANDLE OPTIONS REQUEST (CORS PREFLIGHT)
        # =====================================================
        if request.httprequest.method == 'OPTIONS':
            origin = request.httprequest.headers.get('Origin') or '*'
            return request.make_response(
                '',
                headers=[
                    ('Access-Control-Allow-Origin', origin),    # ✅ Must be here too
                    ('Access-Control-Allow-Methods', 'POST, OPTIONS'),
                    ('Access-Control-Allow-Headers', 'Origin, Content-Type, Accept, Authorization'),
                    ('Access-Control-Max-Age', '86400'),        # ✅ Cache preflight 24hrs
                ],
                status=200
            )

        # =====================================================
        # TOKEN VALIDATION
        # =====================================================
        if not self._check_auth_token():
            return self._response({'status': 401, 'message': 'Unauthorized'}, 401)

        try:
            # =================================================
            # GET REQUEST DATA
            # =================================================
            raw_data = request.httprequest.data.decode('utf-8')
            data = json.loads(raw_data or "{}")

            # =================================================
            # VALIDATION
            # =================================================
            if not data.get('name'):
                return self._response({'status': 400, 'message': 'Lead name is required'}, 400)

            if not data.get('email_from'):
                return self._response({'status': 400, 'message': 'Email is required'}, 400)

            # =================================================
            # CREATE LEAD
            # =================================================
            lead_vals = {
                'name': data.get('name'),
                'contact_name': data.get('contact_name'),
                'email_from': data.get('email_from'),
                'phone': data.get('phone'),
                'website': data.get('website'),
                'description': data.get('description'),
            }
            lead = request.env['crm.lead'].sudo().create(lead_vals)

            # =================================================
            # SUCCESS RESPONSE
            # =================================================
            return self._response({
                'status': 200,
                'message': 'Lead created successfully',
                'data': {'lead_id': lead.id}
            }, 200)

        except Exception as e:
            return self._response({
                'status': 500,
                'message': 'Error creating lead',
                'error': str(e)
            }, 500)