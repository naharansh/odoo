from odoo import models, fields
from odoo.exceptions import UserError


class TimerStopWizard(models.TransientModel):
    _name = 'timer.stop.wizard'
    _description = 'Stop Timer Wizard'

    description = fields.Text(string="Work Description", required=True)
    task_id = fields.Many2one('project.task', required=True)
    analytic_line_id = fields.Many2one('account.analytic.line')

    def action_confirm_stop(self):
        line = self.analytic_line_id

        if not line or not line.x_timer_start:
            raise UserError("No running timer found!")

        end_time = fields.Datetime.now()

        # ⏱️ Real elapsed time using our own stored field
        duration = (end_time - line.x_timer_start).total_seconds() / 3600.0

        # ✅ Write actual duration
        line.write({
            'name': self.description,
            'unit_amount': round(duration, 4),
            'x_is_timer_running': False,
            'x_timer_start': False,
        })