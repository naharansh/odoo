from odoo import models, fields, api

class AccountAnalyticLine(models.Model):
    _inherit = 'account.analytic.line'

    timer_start = fields.Datetime("Timer Start")
    is_timer_running = fields.Boolean("Timer Running", default=False)
    