from odoo import models, fields
from odoo.exceptions import UserError, ValidationError


class AccountAnalyticLine(models.Model):
    _inherit = 'account.analytic.line'

    x_timer_start = fields.Datetime(string="Timer Start", copy=False)
    x_is_timer_running = fields.Boolean(string="Timer Running", default=False, copy=False)


class ProjectTask(models.Model):
    _inherit = 'project.task'

    is_timer_running = fields.Boolean(
        compute="_compute_timer_running",
        string="Is Timer Running"
    )

    def write(self, vals):
        if 'stage_id' in vals:
            for task in self:
                if task.is_timer_running and vals['stage_id'] != task.stage_id.id:
                    raise ValidationError("You cannot change the status of the task while the timer is running. Please stop the timer first.")
        return super(ProjectTask, self).write(vals)

    def _compute_timer_running(self):
        for task in self:
            user = task.user_ids[:1]
            employee = user.employee_id if user else None
            if not employee:
                task.is_timer_running = False
                continue
            running = self.env['account.analytic.line'].search([
                ('employee_id', '=', employee.id),
                ('task_id', '=', task.id),
                ('x_is_timer_running', '=', True)
            ], limit=1)
            task.is_timer_running = bool(running)

    def action_toggle_timer(self):
        for task in self:
            user = task.user_ids[:1]
            employee = user.employee_id if user else None
            if not employee:
                raise UserError("Employee not linked to user!")

            running = self.env['account.analytic.line'].search([
                ('employee_id', '=', employee.id),
                ('task_id', '=', task.id),
                ('x_is_timer_running', '=', True)
            ], limit=1)

            if running:
                # STOP TIMER → open wizard
                return {
                    'type': 'ir.actions.act_window',
                    'name': 'Stop Timer',
                    'res_model': 'timer.stop.wizard',
                    'view_mode': 'form',
                    'target': 'new',
                    'context': {
                        'default_task_id': task.id,
                        'default_analytic_line_id': running.id,
                    }
                }
            else:
                # START TIMER
                existing_timer = self.env['account.analytic.line'].search([
                    ('employee_id', '=', employee.id),
                    ('x_is_timer_running', '=', True)
                ], limit=1)

                if existing_timer:
                    raise UserError("You already have a running timer!")

                # ✅ Always create a NEW line with our own stored fields
                self.env['account.analytic.line'].create({
                    'name': f"Work on {task.name}",
                    'task_id': task.id,
                    'project_id': task.project_id.id,
                    'employee_id': employee.id,
                    'unit_amount': 0,
                    'x_timer_start': fields.Datetime.now(),  # ✅ our own field
                    'x_is_timer_running': True,              # ✅ our own field
                })