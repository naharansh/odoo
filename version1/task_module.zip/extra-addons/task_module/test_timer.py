from odoo.exceptions import ValidationError

def run_test(env):
    task = env['project.task'].browse(4)
    employee = task.user_ids[:1].employee_id
    
    # Create running timer
    timer = env['account.analytic.line'].create({
        'name': 'Test Timer',
        'task_id': task.id,
        'project_id': task.project_id.id,
        'employee_id': employee.id,
        'unit_amount': 0,
        'x_timer_start': env['project.task']._fields['write_date'].now(),
        'x_is_timer_running': True,
    })
    
    task.invalidate_recordset()
    print('Is Timer Running:', task.is_timer_running)
    
    # Try to change stage_id while timer is running
    try:
        task.write({'stage_id': 10})
        print('ERROR: Stage was changed while timer is running!')
    except ValidationError as e:
        print('SUCCESS: Blocked stage change with message:', str(e))
    
    # Delete timer and retry
    timer.unlink()
    task.invalidate_recordset()
    print('Is Timer Running after stop:', task.is_timer_running)
    
    try:
        task.write({'stage_id': 10})
        print('SUCCESS: Stage changed successfully after stopping timer!')
    except Exception as ex:
        print('ERROR: Failed to change stage after stopping timer:', str(ex))

run_test(self.env)
