# -*- coding: utf-8 -*-
{
    'name': "odoo_sign",
    'version': '1.0',
    'license': 'LGPL-3',

    'depends': [
        'base',
        'sale',
        'sale_management',
        'portal',
        'mail',
        'website',
        'website_sale',
        'web',
    ],

    'data': [
        'views/views.xml',
        # 'views/report.xml',
        # 'views/templates.xml',
        # 'views/portal_sale_order.xml',
        'views/email_template.xml',
        'views/sign_template.xml',
    ],

    "assets": {
        "web.assets_frontend": [
            "odoo_sign/static/src/js/signature.js",
            "odoo_sign/static/src/css/style.css",
        ],
    },

    'installable': True,
    'application': False,
}