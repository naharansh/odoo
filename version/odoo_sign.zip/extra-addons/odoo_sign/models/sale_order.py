from odoo import models, fields, api
import base64, secrets

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    customer_sign = fields.Binary("Customer Signature")
    sender_sign = fields.Binary("Sender Signature")
    is_signed = fields.Boolean("Is Signed", compute='_compute_is_signed', store=True)
    signature_token = fields.Char("Signature Token", copy=False)
    access_token = fields.Char("Security Token", copy=False)

    @api.depends('customer_sign', 'sender_sign')
    def _compute_is_signed(self):
        for order in self:
            order.is_signed = bool(order.customer_sign and order.sender_sign)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if not vals.get('access_token'):
                vals['access_token'] = secrets.token_urlsafe(16)
            if not vals.get('signature_token'):
                vals['signature_token'] = secrets.token_urlsafe(32)
        return super().create(vals_list)

    def action_preview_sign(self):
        self.ensure_one()
        if not self.signature_token:
            self.signature_token = secrets.token_urlsafe(32)
        return {
            'type': 'ir.actions.act_url',
            'url': f'/my/sign/{self.signature_token}',
            'target': 'new',
        }
