odoo.define('odoo_sign.signature', [], function (require) {
   "use strict";

   document.addEventListener("DOMContentLoaded", function() {
      const canvas = document.getElementById("signature-pad");
      if (!canvas) return;

      const ctx = canvas.getContext("2d");
      let drawing = false;

      canvas.addEventListener("mousedown", () => { drawing = true; ctx.beginPath(); });
      canvas.addEventListener("mouseup", () => drawing = false);
      canvas.addEventListener("mousemove", draw);

      function draw(e) {
        if (!drawing) return;
        ctx.lineTo(e.offsetX, e.offsetY);
        ctx.stroke();
      }

      document.getElementById("submit").onclick = () => {
        const dataURL = canvas.toDataURL();
        const token = window.location.pathname.split('/').pop();
        fetch(`/my/sign/submit/${token}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({ signature: dataURL })
        }).then(() => window.location.reload());
      };

      document.getElementById("reject").onclick = () => {
        const token = window.location.pathname.split('/').pop();
        fetch(`/my/sign/reject/${token}`, { method: 'POST' })
          .then(() => window.location.reload());
      };
   });
});
