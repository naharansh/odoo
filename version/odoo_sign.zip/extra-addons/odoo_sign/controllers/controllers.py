from odoo import http
from odoo.http import request

class SaleSignController(http.Controller):

    @http.route('/my/sign/<string:token>', type='http', auth='public', website=True)
    def sign_page(self, token, **kwargs):
        order = request.env['sale.order'].sudo().search([
            ('signature_token', '=', token)
        ], limit=1)
        if not order:
            return request.not_found()

        return request.render('odoo_sign.sign_template', {
            'order': order,
        })

    @http.route('/my/sign/submit/<string:token>', type='http', auth='public', website=True, methods=['POST'], csrf=False)
    def sign_submit(self, token, **kwargs):
        order = request.env['sale.order'].sudo().search([
            ('signature_token', '=', token)
        ], limit=1)
        if not order:
            return request.not_found()

        signature = kwargs.get('signature')
        if signature:
            import base64
            if ',' in signature:
                signature = signature.split(',')[1]
            order.sudo().write({'customer_sign': signature})

            template = request.env.ref('odoo_sign.email_template_signed_quotation', raise_if_not_found=False)
            if template:
                template.sudo().send_mail(order.id, force_send=True)

        return request.redirect('/my/orders/%s' % order.id)

    @http.route('/my/sign/reject/<string:token>', type='http', auth='public', website=True, methods=['POST'], csrf=False)
    def sign_reject(self, token, **kwargs):
        order = request.env['sale.order'].sudo().search([
            ('signature_token', '=', token)
        ], limit=1)
        if not order:
            return request.not_found()

        order.sudo().write({'state': 'cancel'})
        return request.redirect('/my/orders/%s' % order.id)
