# -*- coding: utf-8 -*-

from odoo import models, fields

class DocumentTag(models.Model):
    _name = 'document_sign.tag'
    _description = 'Document Tag'

    name = fields.Char(string='Tag Name', required=True)
    color = fields.Integer(string='Color')
