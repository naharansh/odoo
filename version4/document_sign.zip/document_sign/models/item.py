# -*- coding: utf-8 -*-

from odoo import models, fields

class SignItem(models.Model):
    _name = 'document_sign.item'
    _description = 'Signature Field Item'

    document_id = fields.Many2one('document_sign.document', string='Document', required=False, ondelete='cascade')
    type = fields.Selection([
        ('signature', 'Signature'),
        ('initial', 'Initial'),
        ('text', 'Text'),
        ('date', 'Date')
    ], string='Field Type', required=True, default='signature')
    role = fields.Selection([
        ('signer_1', 'Signer 1'),
        ('signer_2', 'Signer 2'),
        ('signer_3', 'Signer 3'),
        ('signer_4', 'Signer 4')
    ], string='Responsible', default='signer_1')
    
    # Store the relative position (percentage or points)
    page = fields.Integer(string='Page Number', required=True, default=1)
    pos_x = fields.Float(string='X Position', required=True, default=0.0)
    pos_y = fields.Float(string='Y Position', required=True, default=0.0)
    width = fields.Float(string='Width', required=True, default=0.15)
    height = fields.Float(string='Height', required=True, default=0.05)
    
    # Value entered by the signer (could be base64 image for signature, or string for text)
    # Actually, the value should be stored per *request*, not on the template item itself,
    # if the document is a template. But if a document is 1:1 with a request, we can store it here.
    # To keep it simple for now, we'll assume a 1:1 relationship between document and request,
    # or that the item is instantiated per request. Let's add a request_id.
    request_id = fields.Many2one('document_sign.request', string='Signature Request', ondelete='cascade')
    
    value = fields.Text(string='Filled Value')
