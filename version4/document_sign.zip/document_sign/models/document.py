# -*- coding: utf-8 -*-

from odoo import models, fields, api

class SignDocument(models.Model):
    _name = 'document_sign.document'
    _description = 'Signature Document Template'

    name = fields.Char(string='Document Name', required=True)
    attachment_id = fields.Binary(string='PDF Document', required=True, ondelete='cascade')
    attachment_name = fields.Char(string='Filename')
    item_ids = fields.One2many('document_sign.item', 'document_id', string='Signature Fields')
    request_ids = fields.One2many('document_sign.request', 'document_id', string='Signature Requests')
    tag_id = fields.Many2one('document_sign.tag', string='Tag')

    # Utility field to store the base64 content easily, if needed, though attachment_id is standard.
    # We will use attachment_id for the primary file storage.

    def action_request_signature(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'New Signature Request',
            'res_model': 'document_sign.request',
            'view_mode': 'form',
            'context': {
                'default_document_id': self.id,
            },
            'target': 'new',
        }
