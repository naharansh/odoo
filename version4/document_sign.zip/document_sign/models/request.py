# -*- coding: utf-8 -*-

import uuid
from odoo import models, fields, api

class SignRequest(models.Model):
    _name = 'document_sign.request'
    _description = 'Signature Request'

    name = fields.Char(string='Reference', required=True, copy=False, readonly=True, default=lambda self: 'New')
    document_id = fields.Many2one('document_sign.document', string='Document', required=True)
    signer_ids = fields.One2many('document_sign.request.signer', 'request_id', string='Signers', copy=True)
    item_ids = fields.One2many('document_sign.item', 'request_id', string='Signature Fields')
    partner_ids = fields.Many2many('res.partner', string='Signers', compute='_compute_partner_ids', store=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('sent', 'Sent'),
        ('partial', 'Partially Signed'),
        ('signed', 'Signed'),
        ('canceled', 'Canceled')
    ], string='Status', default='draft', required=True)
    
    signed_document = fields.Binary(string='Signed PDF Document', attachment=True)
    signed_document_name = fields.Char(string='Signed Document Name')
    pdf_content = fields.Binary(string='PDF Content', compute='_compute_pdf_content')

    @api.depends('signed_document', 'document_id.attachment_id')
    def _compute_pdf_content(self):
        for req in self:
            req.pdf_content = req.signed_document or req.document_id.attachment_id
    
    @api.depends('signer_ids.partner_id')
    def _compute_partner_ids(self):
        for record in self:
            record.partner_ids = record.signer_ids.mapped('partner_id')
    
    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', 'New') == 'New':
                vals['name'] = self.env['ir.sequence'].next_by_code('document_sign.request') or 'New'
        
        records = super().create(vals_list)
        
        # Clone items from document to request
        for record in records:
            if record.document_id:
                for item in record.document_id.item_ids:
                    item.copy({
                        'document_id': False,
                        'request_id': record.id,
                    })
        return records

    def action_download_signed_pdf(self):
        self.ensure_one()
        if not self.signed_document:
            return False
            
        return {
            'type': 'ir.actions.act_url',
            'url': f'/web/content/document_sign.request/{self.id}/signed_document/{self.signed_document_name}?download=true',
            'target': 'self',
        }

    def action_send_request(self):
        self.ensure_one()
        template = self.env.ref('document_sign.mail_template_sign_request_signer')
        for signer in self.signer_ids:
            template.send_mail(signer.id, force_send=True)
        self.write({'state': 'sent'})
        return True

class SignRequestSigner(models.Model):
    _name = 'document_sign.request.signer'
    _description = 'Signature Request Signer'

    request_id = fields.Many2one('document_sign.request', string='Signature Request', ondelete='cascade')
    partner_id = fields.Many2one('res.partner', string='Signer', required=True)
    access_token = fields.Char('Security Token', copy=False, default=lambda self: str(uuid.uuid4()))
    role = fields.Selection([
        ('signer_1', 'Signer 1'),
        ('signer_2', 'Signer 2'),
        ('signer_3', 'Signer 3'),
        ('signer_4', 'Signer 4')
    ], string='Responsible', default='signer_1')
    state = fields.Selection([
        ('sent', 'Sent'),
        ('signed', 'Signed')
    ], string='Status', default='sent')
