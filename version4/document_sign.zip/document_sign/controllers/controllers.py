# -*- coding: utf-8 -*-
# from odoo import http


# class OdooSign(http.Controller):
#     @http.route('/odoo_sign/odoo_sign', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/odoo_sign/odoo_sign/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('odoo_sign.listing', {
#             'root': '/odoo_sign/odoo_sign',
#             'objects': http.request.env['odoo_sign.odoo_sign'].search([]),
#         })

#     @http.route('/odoo_sign/odoo_sign/objects/<model("odoo_sign.odoo_sign"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('odoo_sign.object', {
#             'object': obj
#         })

