import json
from werkzeug.exceptions import NotFound
from odoo import http
from odoo.http import request

class SignPortal(http.Controller):

    @http.route('/sign/document/<string:token>', type='http', auth='public')
    def sign_document_portal(self, token, **kw):
        # Find the signer by token
        signer = request.env['document_sign.request.signer'].sudo().search([('access_token', '=', token)], limit=1)
        
        if not signer:
            raise NotFound()

        sign_request = signer.request_id

        # Get the document and fields
        document = sign_request.document_id
        items = document.item_ids

        # We pass the items as a list of dicts to the frontend
        item_data = []
        for item in sign_request.item_ids:
            item_data.append({
                'id': item.id,
                'type': item.type,
                'page': item.page,
                'pos_x': item.pos_x,
                'pos_y': item.pos_y,
                'width': item.width,
                'height': item.height,
                'role': item.role,
                'is_editable': item.role == signer.role,
                'value': item.value,
            })

        # In a real scenario, we might have an image/binary URL. We can pass the base64 data directly for simplicity,
        # or expose a route to download the PDF. Exposing a route is better for performance.
        # Use a secure token-based route for the PDF to ensure public users can view it
        pdf_url = f'/sign/pdf/{token}'

        values = {
            'sign_request': sign_request,
            'signer': signer,
            'document': document,
            'item_data': item_data,
            'pdf_url': pdf_url,
            'token': token,
            'json': json,
        }

        return request.render('document_sign.portal_sign_document', values)

    @http.route('/sign/document/submit', type='json', auth='public', methods=['POST'])
    def sign_document_submit(self, token, signatures, **kw):
        signer = request.env['document_sign.request.signer'].sudo().search([('access_token', '=', token)], limit=1)
        if not signer:
            return {'success': False, 'error': 'Invalid token'}
            
        sign_request = signer.request_id
        
        # Mark signer as signed
        signer.sudo().write({'state': 'signed'})
        
        # Check if all signers are signed
        all_signed = all(s.state == 'signed' for s in sign_request.signer_ids)
        if all_signed:
            sign_request.sudo().write({'state': 'signed'})
        else:
            sign_request.sudo().write({'state': 'partial'})
        
        items_with_data = []
        # Save signatures to the items
        for item_id, sig_data in signatures.items():
            # Check if it belongs to the request
            item = request.env['document_sign.item'].sudo().browse(int(item_id))
            if item.request_id == sign_request:
                item.write({'value': sig_data})
                items_with_data.append({'item': item, 'data': sig_data})
                
        # Generate the signed PDF
        try:
            import base64
            import io
            import PyPDF2
            from reportlab.pdfgen import canvas
            from reportlab.lib.utils import ImageReader
            
            document = sign_request.document_id
            original_pdf_data = base64.b64decode(document.attachment_id)
            
            # Compatible with PyPDF2 1.26.0
            reader = PyPDF2.PdfFileReader(io.BytesIO(original_pdf_data))
            writer = PyPDF2.PdfFileWriter()

            for page_num in range(reader.getNumPages()):
                page = reader.getPage(page_num)
                # Fallback to mediaBox
                mb = page.mediaBox
                page_width = float(mb.getWidth())
                page_height = float(mb.getHeight())

                # Get all items in the request that have a value (already signed)
                page_items = sign_request.item_ids.filtered(lambda i: i.page == (page_num + 1) and i.value)
                
                if page_items:
                    packet = io.BytesIO()
                    can = canvas.Canvas(packet, pagesize=(page_width, page_height))
                    
                    for item in page_items:
                        sig_data = item.value
                        
                        if ',' in sig_data:
                            sig_data = sig_data.split(',')[1]
                        
                        img_data = base64.b64decode(sig_data)
                        img_stream = io.BytesIO(img_data)
                        img_reader = ImageReader(img_stream)
                        
                        x = item.pos_x * page_width
                        y_top_down = item.pos_y * page_height
                        w = item.width * page_width
                        h = item.height * page_height
                        
                        # Convert Y to bottom-up (ReportLab default)
                        y = page_height - y_top_down - h
                        
                        can.drawImage(img_reader, x, y, width=w, height=h, mask='auto')
                        
                    can.save()
                    packet.seek(0)
                    
                    overlay_pdf = PyPDF2.PdfFileReader(packet)
                    page.mergePage(overlay_pdf.getPage(0))
                    
                writer.addPage(page)
                
            output = io.BytesIO()
            writer.write(output)
            signed_b64 = base64.b64encode(output.getvalue()).decode('utf-8')
            
            # Save the final signed document on the request record
            sign_request.sudo().write({
                'signed_document': signed_b64,
                'signed_document_name': f"{document.name}_signed.pdf"
            })
            
        except Exception as e:
            # Log the error but don't fail the request if PDF generation fails
            import logging
            _logger = logging.getLogger(__name__)
            _logger.error(f"Failed to generate signed PDF: {str(e)}")

        return {'success': True}

    @http.route('/sign/download/<string:token>', type='http', auth='public')
    def sign_document_download(self, token, **kw):
        signer = request.env['document_sign.request.signer'].sudo().search([('access_token', '=', token)], limit=1)
        if not signer:
             # Try searching by request name/token if needed, but for now we use signer tokens
             sign_request = request.env['document_sign.request'].sudo().search([('signer_ids.access_token', '=', token)], limit=1)
        else:
            sign_request = signer.request_id

        if not sign_request or not sign_request.signed_document:
            raise NotFound()

        import base64
        file_content = base64.b64decode(sign_request.signed_document)
        filename = sign_request.signed_document_name or 'signed_document.pdf'

        return request.make_response(file_content, [
            ('Content-Type', 'application/pdf'),
            ('Content-Disposition', http.content_disposition(filename))
        ])

    @http.route('/sign/pdf/<string:token>', type='http', auth='public')
    def sign_document_pdf(self, token, **kw):
        signer = request.env['document_sign.request.signer'].sudo().search([('access_token', '=', token)], limit=1)
        if not signer:
            raise NotFound()
            
        sign_request = signer.request_id
        if not sign_request or not sign_request.document_id.attachment_id:
            raise NotFound()

        import base64
        file_content = base64.b64decode(sign_request.document_id.attachment_id)
        filename = f"{sign_request.document_id.name}.pdf"

        return request.make_response(file_content, [
            ('Content-Type', 'application/pdf'),
            ('Content-Disposition', http.content_disposition(filename))
        ])
