/** @odoo-module **/

import { Component, useState, onWillStart, onMounted } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

function loadJS(url) {
    return new Promise((resolve, reject) => {
        const script = document.createElement("script");
        script.src = url;
        script.onload = resolve;
        script.onerror = reject;
        document.head.appendChild(script);
    });
}

export class DocumentEditor extends Component {
    setup() {
        this.orm = useService("orm");
        this.actionService = useService("action");
        this.state = useState({
            documentId: this.props.action.context.active_id || null,
            documentName: "Loading...",
            items: [],
            pdfLoaded: false,
            selectedItemId: null,
            pages: [],
            tag_id: null,
            allTags: [],
            showTagsDropdown: false,
        });

        onWillStart(async () => {
            if (this.state.documentId) {
                const docs = await this.orm.read("document_sign.document", [this.state.documentId], ["name", "attachment_id", "item_ids", "tag_id"]);
                if (docs.length > 0) {
                    this.state.documentName = docs[0].name;
                    this.state.tag_id = docs[0].tag_id ? docs[0].tag_id[0] : null;
                    if (docs[0].attachment_id) {
                        this.pdfBase64 = docs[0].attachment_id;
                    }
                    if (docs[0].item_ids.length > 0) {
                        const items = await this.orm.read("document_sign.item", docs[0].item_ids, ["type", "page", "pos_x", "pos_y", "width", "height", "role"]);
                        this.state.items = items.map(i => ({
                            id: i.id,
                            type: i.type,
                            page: i.page,
                            pos_x: i.pos_x,
                            pos_y: i.pos_y,
                            width: i.width,
                            height: i.height,
                            role: i.role || 'signer_1',
                        }));
                    }
                }
                this.state.allTags = await this.orm.searchRead("document_sign.tag", [], ["name", "color"]);
            }
            // Load PDF.js from CDN
            await loadJS("https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.min.js");
            window.pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.worker.min.js";
        });
        
        onMounted(() => {
            if (this.pdfBase64) {
                this.renderPdf();
            }
        });
    }

    async renderPdf() {
        try {
            const pdfData = atob(this.pdfBase64);
            const loadingTask = window.pdfjsLib.getDocument({data: pdfData});
            const pdf = await loadingTask.promise;
            
            this.state.pages = Array.from({length: pdf.numPages}, (_, i) => i + 1);
            
            // Wait for Owl to render the containers
            setTimeout(async () => {
                for (let i = 1; i <= pdf.numPages; i++) {
                    const page = await pdf.getPage(i);
                    const scale = 1.5;
                    const viewport = page.getViewport({scale: scale});

                    const canvas = document.getElementById(`canvas-page-${i}`);
                    const pageContainer = document.getElementById(`page-container-${i}`);
                    if (canvas && pageContainer) {
                        const context = canvas.getContext("2d");
                        canvas.width = viewport.width;
                        canvas.height = viewport.height;
                        
                        pageContainer.style.width = viewport.width + 'px';
                        pageContainer.style.height = viewport.height + 'px';
                        
                        const renderContext = {
                            canvasContext: context,
                            viewport: viewport
                        };
                        await page.render(renderContext).promise;
                    }
                }
                this.state.pdfLoaded = true;
            }, 100);
        } catch (e) {
            console.error("Error rendering PDF:", e);
        }
    }

    getItemsForPage(pageNum) {
        return this.state.items.filter(i => i.page === pageNum);
    }

    updateSelectedItemPage(pageNum) {
        const item = this.state.items.find(i => i.id === this.state.selectedItemId);
        if (item) {
            item.page = parseInt(pageNum);
        }
    }

    addField(type) {
        if (!this.state.pdfLoaded) return;
        const newItem = {
            id: 'temp_' + Date.now(),
            type: type,
            page: 1, // Default to first page for now
            pos_x: 0.1, 
            pos_y: 0.1,
            width: 0.15,
            height: 0.05,
            role: 'signer_1',
        };
        this.state.items.push(newItem);
        this.state.selectedItemId = newItem.id;
    }

    selectItem(item) {
        this.state.selectedItemId = item.id;
    }

    updateSelectedItemRole(role) {
        const item = this.state.items.find(i => i.id === this.state.selectedItemId);
        if (item) {
            item.role = role;
        }
    }

    deleteSelectedItem() {
        this.state.items = this.state.items.filter(i => i.id !== this.state.selectedItemId);
        this.state.selectedItemId = null;
    }

    startDrag(e, item) {
        e.preventDefault();
        e.stopPropagation();
        
        this.draggingItem = item;
        const itemEl = e.target.closest('.position-absolute');
        const itemRect = itemEl.getBoundingClientRect();
        
        // Store offset of mouse from item's top-left
        this.dragOffsetX = e.clientX - itemRect.left;
        this.dragOffsetY = e.clientY - itemRect.top;
        
        this.onMouseMove = this.handleMouseMove.bind(this);
        this.onMouseUp = this.handleMouseUp.bind(this);
        
        document.addEventListener('mousemove', this.onMouseMove);
        document.addEventListener('mouseup', this.onMouseUp);
    }

    handleMouseMove(e) {
        if (!this.draggingItem) return;
        
        // Find which page container we are over
        const containers = document.querySelectorAll('.o_pdf_page_wrapper');
        let targetPage = this.draggingItem.page;
        let targetRect = null;
        
        for (const cont of containers) {
            const rect = cont.getBoundingClientRect();
            // Use a bit of padding to make it easier to switch pages
            if (e.clientX >= rect.left && e.clientX <= rect.right &&
                e.clientY >= rect.top && e.clientY <= rect.bottom) {
                targetPage = parseInt(cont.id.split('-').pop());
                targetRect = rect;
                break;
            }
        }
        
        if (targetRect) {
            this.draggingItem.page = targetPage;
            
            const xPct = (e.clientX - targetRect.left - this.dragOffsetX) / targetRect.width;
            const yPct = (e.clientY - targetRect.top - this.dragOffsetY) / targetRect.height;
            
            this.draggingItem.pos_x = Math.max(0, Math.min(1 - this.draggingItem.width, xPct));
            this.draggingItem.pos_y = Math.max(0, Math.min(1 - this.draggingItem.height, yPct));
        }
    }

    handleMouseUp() {
        this.draggingItem = null;
        document.removeEventListener('mousemove', this.onMouseMove);
        document.removeEventListener('mouseup', this.onMouseUp);
    }

    selectTag(tagId) {
        this.state.tag_id = tagId;
        this.state.showTagsDropdown = false;
    }

    getTagName(tagId) {
        const tag = this.state.allTags.find(t => t.id === tagId);
        return tag ? tag.name : '';
    }

    async saveFields() {
        try {
            // First clear existing items for this document
            await this.orm.call("document_sign.document", "write", [[this.state.documentId], {
                item_ids: [[5, 0, 0]],
                tag_id: this.state.tag_id
            }]);
            
            // Prepare items
            const newItems = this.state.items.map(item => {
                return [0, 0, {
                    type: item.type,
                    page: item.page,
                    pos_x: item.pos_x,
                    pos_y: item.pos_y,
                    width: item.width,
                    height: item.height,
                    role: item.role,
                }];
            });
            
            await this.orm.call("document_sign.document", "write", [[this.state.documentId], {
                item_ids: newItems
            }]);
            
            this.goBack();
        } catch (e) {
            console.error("Error saving fields:", e);
        }
    }

    goBack() {
        this.actionService.doAction({
            type: "ir.actions.act_window",
            res_model: "document_sign.document",
            res_id: this.state.documentId,
            views: [[false, "form"]],
            target: "current",
        });
    }
}

DocumentEditor.template = "document_sign.DocumentEditor";

registry.category("actions").add("document_sign.document_editor", DocumentEditor);
