/** @odoo-module **/

import { Component, useState, onWillStart, onMounted } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

function loadJS(url) {
    return new Promise((resolve, reject) => {
        const script = document.createElement("script");
        script.src = url;
        script.onload = resolve;
        script.onerror = reject;
        document.head.appendChild(script);
    });
}

export class RequestViewer extends Component {
    setup() {
        this.orm = useService("orm");
        this.actionService = useService("action");
        this.state = useState({
            requestId: this.props.action.context.active_id || null,
            documentName: "Loading...",
            pdfLoaded: false,
            pages: [],
            status: "",
        });

        onWillStart(async () => {
            if (this.state.requestId) {
                const reqs = await this.orm.read("document_sign.request", [this.state.requestId], ["document_id", "pdf_content", "state"]);
                if (reqs.length > 0) {
                    this.state.documentName = reqs[0].document_id[1];
                    this.state.status = reqs[0].state;
                    if (reqs[0].pdf_content) {
                        this.pdfBase64 = reqs[0].pdf_content;
                    }
                }
            }
            await loadJS("https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.min.js");
            window.pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.worker.min.js";
        });
        
        onMounted(() => {
            if (this.pdfBase64) {
                this.renderPdf();
            }
        });
    }

    async renderPdf() {
        try {
            const pdfData = atob(this.pdfBase64);
            const loadingTask = window.pdfjsLib.getDocument({data: pdfData});
            const pdf = await loadingTask.promise;
            
            this.state.pages = Array.from({length: pdf.numPages}, (_, i) => i + 1);
            
            setTimeout(async () => {
                for (let i = 1; i <= pdf.numPages; i++) {
                    const page = await pdf.getPage(i);
                    const scale = 1.5;
                    const viewport = page.getViewport({scale: scale});

                    const canvas = document.getElementById(`rv-canvas-page-${i}`);
                    const pageContainer = document.getElementById(`rv-page-container-${i}`);
                    if (canvas && pageContainer) {
                        const context = canvas.getContext("2d");
                        canvas.width = viewport.width;
                        canvas.height = viewport.height;
                        
                        pageContainer.style.width = viewport.width + 'px';
                        pageContainer.style.height = viewport.height + 'px';
                        
                        const renderContext = {
                            canvasContext: context,
                            viewport: viewport
                        };
                        await page.render(renderContext).promise;
                    }
                }
                this.state.pdfLoaded = true;
            }, 100);
        } catch (e) {
            console.error("Error rendering PDF:", e);
        }
    }

    goBack() {
        this.actionService.doAction({
            type: "ir.actions.act_window",
            res_model: "document_sign.request",
            views: [[false, "list"], [false, "kanban"], [false, "form"]],
            target: "current",
        });
    }
}

RequestViewer.template = "document_sign.RequestViewer";

registry.category("actions").add("document_sign.request_viewer", RequestViewer);
