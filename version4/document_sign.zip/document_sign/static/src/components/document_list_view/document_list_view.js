/** @odoo-module **/

import { ListController } from "@web/views/list/list_controller";
import { listView } from "@web/views/list/list_view";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { useRef } from "@odoo/owl";

export class DocumentListUploadController extends ListController {
    setup() {
        super.setup();
        this.orm = useService("orm");
        this.notification = useService("notification");
        this.action = useService("action");
        this.fileInput = useRef("fileInput");
    }

    async onUploadPdf(ev) {
        const file = ev.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = async (e) => {
            const base64 = e.target.result.split(',')[1];
            try {
                const documentId = await this.orm.create("document_sign.document", [{
                    name: file.name,
                    attachment_id: base64,
                    attachment_name: file.name,
                }]);
                
                this.notification.add("Document uploaded successfully", { type: "success" });
                
                // Open the newly created document in the editor
                this.action.doAction({
                    type: "ir.actions.client",
                    tag: "document_sign.document_editor",
                    context: { active_id: documentId[0] },
                });
            } catch (error) {
                console.error(error);
                this.notification.add("Failed to upload document", { type: "danger" });
            }
        };
        reader.readAsDataURL(file);
    }

    async openRecord(record) {
        if (this.props.resModel === "document_sign.document") {
            this.action.doAction({
                type: "ir.actions.client",
                tag: "document_sign.document_editor",
                context: { active_id: record.resId },
            });
            return;
        }
        if (this.props.resModel === "document_sign.request") {
            this.action.doAction({
                type: "ir.actions.client",
                tag: "document_sign.request_viewer",
                context: { active_id: record.resId },
            });
            return;
        }
        super.openRecord(record);
    }
}

export const DocumentListUploadView = {
    ...listView,
    Controller: DocumentListUploadController,
    buttonTemplate: "document_sign.DocumentListUploadButtons",
};

registry.category("views").add("document_sign_list_upload", DocumentListUploadView);
