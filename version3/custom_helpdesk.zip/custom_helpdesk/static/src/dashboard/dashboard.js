/** @odoo-module **/

import { Component, useState, onWillStart } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

export class HelpdeskDashboard extends Component {
    static template = "custom_helpdesk.HelpdeskDashboard";

    setup() {
        this.orm = useService("orm");
        this.actionService = useService("action");

        this.state = useState({
            uid: null,
            data: {
                my_tickets: {
                    tickets: { count: 0, avg_hours: 0, failed: 0 },
                    high_priority: { count: 0, avg_hours: 0, failed: 0 },
                    urgent: { count: 0, avg_hours: 0, failed: 0 }
                },
                my_performance: {
                    today: { closed: 0, sla: "/ %" },
                    last_7_days: { closed: 0, sla: "/ %" },
                    target: { closed: 1, sla: "85%" }
                },
                teams: []
            },
            loading: true
        });

        onWillStart(async () => {
            await this.loadData();
        });
    }

    async loadData() {
        this.state.loading = true;
        try {
            // Python returns uid as an integer — guaranteed safe for domain filters
            const result = await this.orm.call("helpdesk.ticket", "get_dashboard_data", []);
            this.state.uid = result.uid;
            this.state.data = result;
        } catch (error) {
            console.error("Error loading helpdesk dashboard data:", error);
        } finally {
            this.state.loading = false;
        }
    }

    openMyTickets(filter = null) {
        // Default: show my tickets in list view
        if (!filter) {
            let domain = [];
            if (this.state.uid) {
                domain.push(["user_id", "=", this.state.uid]);
            }
            this.actionService.doAction({
                type: "ir.actions.act_window",
                name: "My Tickets",
                res_model: "helpdesk.ticket",
                views: [[false, "list"]],
                domain: domain,
                context: { search_default_assigned_me: 1 },
            });
            return;
        }
        // For high priority or urgent, build custom domain
        let domain = [];
        if (this.state.uid) {
            domain.push(["user_id", "=", this.state.uid]);
        }
        if (filter === "high_priority") {
            domain.push(["priority", "=", "2"]);
        } else if (filter === "urgent") {
            domain.push(["priority", "=", "3"]);
        }
        this.actionService.doAction({
            type: "ir.actions.act_window",
            name: "Tickets",
            res_model: "helpdesk.ticket",
            views: [[false, "list"], [false, "kanban"], [false, "form"]],
            domain: domain,
            context: { search_default_assigned_me: 1 },
        });
    }

    openTeamTickets(teamId, filter = null) {
        let domain = [["team_id", "=", teamId]];

        if (filter === "unassigned") {
            domain.push(["user_id", "=", false]);
        } else if (filter === "urgent") {
            domain.push(["priority", "=", "3"]);
        } else if (filter === "failed") {
            domain.push(["sla_status", "=", "failed"]);
        }

        this.actionService.doAction({
            type: "ir.actions.act_window",
            name: "Team Tickets",
            res_model: "helpdesk.ticket",
            views: [[false, "kanban"], [false, "list"], [false, "form"]],
            domain: domain,
            context: {},
        });
    }
}

registry.category("actions").add("helpdesk_dashboard", HelpdeskDashboard);
