from odoo import models, fields, api

class HelpdeskStage(models.Model):
    _inherit = 'helpdesk.stage'
    

    @api.model
    def create(self, vals):
        # If a new stage is marked as default, unset others
        if vals.get('default_stage'):
            self.env['helpdesk.stage'].search([('default_stage', '=', True)]).write({'default_stage': False})
        return super(HelpdeskStage, self).create(vals)

    def write(self, vals):
        res = super(HelpdeskStage, self).write(vals)
        if vals.get('default_stage'):
            # Unset default on all other stages
            self.env['helpdesk.stage'].search([('id', '!=', self.id), ('default_stage', '=', True)]).write({'default_stage': False})
        return res
