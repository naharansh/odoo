from odoo import models, fields


class HelpdeskSLAPolicy(models.Model):
    """SLA Policy model for Odoo Community – mirrors Odoo Enterprise Helpdesk SLA.

    Criteria fields (team, priority, tags, customer) determine which tickets
    this policy applies to.  When a ticket matches, the SLA deadline is set
    to *create_date + duration hours*.
    """
    _name = 'helpdesk.sla.policy'
    _description = 'Helpdesk SLA Policy'
    _order = 'name'

    # ------------------------------------------------------------------
    # Basic information
    # ------------------------------------------------------------------
    name = fields.Char(
        string='Name',
        required=True,
    )

    description = fields.Text(
        string='Description',
    )

    # ------------------------------------------------------------------
    # Matching criteria – same as Odoo Enterprise
    # ------------------------------------------------------------------
    team_id = fields.Many2one(
        'helpdesk.team',
        string='Helpdesk Team',
        help='Leave empty to apply to all teams.',
    )

    priority = fields.Selection([
        ('0', 'Low'),
        ('1', 'Medium'),
        ('2', 'High'),
        ('3', 'Very High'),
    ],
        string='Minimum Priority',
        help='Apply this SLA only to tickets with this priority or higher. '
             'Leave empty to match any priority.',
    )

    tag_ids = fields.Many2many(
        'helpdesk.tag',
        string='Tags',
        help='Apply this SLA only to tickets that have at least one of these tags.',
    )

    customer_ids = fields.Many2many(
        'res.partner',
        string='Customers',
        help='Leave empty to apply to all customers.',
    )

    # ------------------------------------------------------------------
    # Target
    # ------------------------------------------------------------------
    reach_stage_id = fields.Many2one(
        'helpdesk.stage',
        string='Reach Stage',
        required=True,
        help='The SLA is fulfilled when the ticket reaches this stage.',
    )

    duration = fields.Float(
        string='Duration (Hours)',
        required=True,
        default=8.0,
        help='Maximum number of hours allowed to reach the target stage.',
    )

    excluded_stage_ids = fields.Many2many(
        'helpdesk.stage',
        'helpdesk_sla_excluded_stage_rel',
        'sla_id',
        'stage_id',
        string='Excluded Stages',
        help='Time spent in these stages will not count toward the SLA deadline.',
    )

    active = fields.Boolean(
        string='Active',
        default=True,
    )
