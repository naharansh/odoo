from odoo import models, fields, api
from datetime import timedelta


class HelpdeskTicketSLA(models.Model):
    """Extends helpdesk.ticket with SLA deadline and status fields."""

    _inherit = 'helpdesk.ticket'

    # ------------------------------------------------------------------
    # SLA fields
    # ------------------------------------------------------------------
    sla_policy_id = fields.Many2one(
        'helpdesk.sla.policy',
        string='SLA Policy',
        compute='_compute_sla_deadline',
        store=True,
    )

    sla_deadline = fields.Datetime(
        string='SLA Deadline',
        compute='_compute_sla_deadline',
        store=True,
    )

    sla_status = fields.Selection([
        ('on_time', 'On Time'),
        ('failed', 'Failed'),
    ],
        string='SLA Status',
        compute='_compute_sla_status',
        store=True,
    )

    # ------------------------------------------------------------------
    # Compute
    # ------------------------------------------------------------------
    @api.depends('team_id', 'priority', 'tag_ids', 'partner_id', 'create_date')
    def _compute_sla_deadline(self):
        for ticket in self:
            policy = ticket._find_matching_sla_policy()
            ticket.sla_policy_id = policy
            if policy:
                start = ticket.create_date or fields.Datetime.now()
                ticket.sla_deadline = start + timedelta(hours=policy.duration or 0)
            else:
                ticket.sla_deadline = False

    @api.depends('sla_deadline')
    def _compute_sla_status(self):
        now = fields.Datetime.now()
        for ticket in self:
            if ticket.sla_deadline:
                ticket.sla_status = 'failed' if now > ticket.sla_deadline else 'on_time'
            else:
                ticket.sla_status = False

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _find_matching_sla_policy(self):
        """Return the best-matching SLA policy for this ticket.

        Matching logic (same as Odoo Enterprise):
        - team must match (or policy has no team restriction)
        - priority must match (or policy has no priority restriction)
        - if policy has tags, ticket must share at least one
        - if policy has a customer, ticket customer must match
        The most specific policy (with the most restrictions) wins.
        """
        domain = [('active', '=', True)]

        # team filter
        if self.team_id:
            domain += ['|',
                       ('team_id', '=', False),
                       ('team_id', '=', self.team_id.id)]
        else:
            domain.append(('team_id', '=', False))

        # priority filter – match policies whose priority <= ticket priority
        if self.priority:
            domain += ['|',
                       ('priority', '=', False),
                       ('priority', '<=', self.priority)]
        else:
            domain.append(('priority', '=', False))

        # customer filter
        if self.partner_id:
            domain += ['|',
                       ('customer_ids', '=', False),
                       ('customer_ids', 'in', [self.partner_id.id])]
        else:
            domain.append(('customer_ids', '=', False))

        policies = self.env['helpdesk.sla.policy'].search(domain)

        # filter by tags: if a policy has tags, the ticket must match at least one
        if self.tag_ids:
            matching = policies.filtered(
                lambda p: not p.tag_ids or bool(p.tag_ids & self.tag_ids)
            )
        else:
            matching = policies.filtered(lambda p: not p.tag_ids)

        # prefer the policy with the smallest duration (strictest)
        return matching[:1] if matching else self.env['helpdesk.sla.policy']
