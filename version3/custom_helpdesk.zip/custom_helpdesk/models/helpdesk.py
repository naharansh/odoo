from odoo import models, fields, api
from odoo.exceptions import ValidationError


# =========================================================
# HELP DESK TEAM
# =========================================================
class HelpdeskTeam(models.Model):
    _name = 'helpdesk.team'
    _description = 'Helpdesk Team'

    name = fields.Char(
        string='Name',
        required=True
    )

    email = fields.Char(
        string='Email Alias',
    )

    active = fields.Boolean(
        string='Active',
        default=True
    )


# =========================================================
# HELP DESK TAG
# =========================================================
class HelpdeskTag(models.Model):
    _name = 'helpdesk.tag'
    _description = 'Helpdesk Tag'

    name = fields.Char(
        string='Name',
        required=True
    )

    color = fields.Integer(
        string='Color'
    )

    active = fields.Boolean(
        string='Active',
        default=True
    )


# =========================================================
# HELP DESK STAGE
# =========================================================
class HelpdeskStage(models.Model):
    _name = 'helpdesk.stage'
    _description = 'Helpdesk Stage'
    _order = 'sequence, id'

    name = fields.Char(
        string='Stage Name',
        required=True
    )

    sequence = fields.Integer(
        string='Sequence',
        default=10
    )

    active = fields.Boolean(
        string='Active',
        default=True
    )

    default_stage = fields.Boolean(
        string='Default Stage',
        default=False
    )

    kanban_state = fields.Selection([
        ('normal', 'In Progress'),
        ('blocked', 'Blocked'),
        ('done', 'Ready')
    ],
        string='Kanban State',
        default='normal',
        required=True,
        help='Tickets moved to this stage will automatically get this kanban state.'
    )

    # =====================================================
    # ONLY ONE DEFAULT STAGE
    # =====================================================
    @api.constrains('default_stage')
    def _check_single_default_stage(self):

        for record in self:

            if record.default_stage:

                existing = self.search([
                    ('default_stage', '=', True),
                    ('id', '!=', record.id)
                ], limit=1)

                if existing:
                    raise ValidationError(
                        'Only one stage can be set as Default Stage.'
                    )


# =========================================================
# HELP DESK TICKET
# =========================================================
class HelpdeskTicket(models.Model):
    _name = 'helpdesk.ticket'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Helpdesk Ticket'

    # =====================================================
    # DEFAULT STAGE
    # =====================================================
    @api.model
    def _get_default_stage(self):

        return self.env[
            'helpdesk.stage'
        ].search([
            ('default_stage', '=', True)
        ], limit=1)

    # -----------------------------------------------------
    # BASIC INFORMATION
    # -----------------------------------------------------
    ticket_id = fields.Char(
        string='Ticket ID',
        required=True,
        copy=False,
        readonly=True,
        default='New'
    )

    name = fields.Char(
        string='Subject',
        required=True,
        tracking=True
    )

    description = fields.Html(
        string='Description'
    )

    active = fields.Boolean(
        string='Active',
        default=True
    )

    # -----------------------------------------------------
    # TEAM & USER
    # -----------------------------------------------------
    team_id = fields.Many2one(
        'helpdesk.team',
        string='Helpdesk Team',
        tracking=True
    )

    user_id = fields.Many2one(
        'res.users',
        string='Assigned To',
        default=lambda self: self.env.user,
        tracking=True
    )

    # -----------------------------------------------------
    # CUSTOMER
    # -----------------------------------------------------
    partner_id = fields.Many2one(
        'res.partner',
        string='Customer',
        tracking=True
    )

    phone = fields.Char(
        string='Phone'
    )

    # -----------------------------------------------------
    # PRIORITY
    # -----------------------------------------------------
    priority = fields.Selection([
        ('0', 'Low'),
        ('1', 'Medium'),
        ('2', 'High'),
        ('3', 'Very High')
    ],
        string='Priority',
        default='0',
        tracking=True
    )

    # -----------------------------------------------------
    # TAGS
    # -----------------------------------------------------
    tag_ids = fields.Many2many(
        'helpdesk.tag',
        string='Tags'
    )

    # -----------------------------------------------------
    # DEADLINE
    # -----------------------------------------------------
    date_deadline = fields.Date(
        string='Deadline',
        tracking=True
    )

    # -----------------------------------------------------
    # RATING
    # -----------------------------------------------------
    rating_value = fields.Selection([
        ('0', 'No Rating'),
        ('1', 'Poor'),
        ('2', 'Average'),
        ('3', 'Good')
    ],
        string='Rating',
        default='0',
        tracking=True
    )

    # -----------------------------------------------------
    # STAGE
    # -----------------------------------------------------
    stage_id = fields.Many2one(
        'helpdesk.stage',
        string='Stage',
        tracking=True,
        group_expand='_read_group_stage_ids',
        default=_get_default_stage
    )

    # -----------------------------------------------------
    # KANBAN STATE
    # -----------------------------------------------------
    kanban_state = fields.Selection([
        ('normal', 'In Progress'),
        ('blocked', 'Blocked'),
        ('done', 'Ready')
    ],
        string='Kanban State',
        default='normal',
        tracking=True
    )

    # =====================================================
    # KANBAN STAGES
    # =====================================================
    @api.model
    def _read_group_stage_ids(self, stages, domain):

        return self.env[
            'helpdesk.stage'
        ].search([], order='sequence asc')

    # =====================================================
    # PARTNER PHONE AUTO FILL
    # =====================================================
    @api.onchange('partner_id')
    def _onchange_partner_id(self):

        if self.partner_id:
            self.phone = self.partner_id.phone or ''

    # =====================================================
    # AUTO UPDATE KANBAN STATE FROM STAGE
    # =====================================================
    @api.onchange('stage_id')
    def _onchange_stage_id(self):

        if self.stage_id:
            self.kanban_state = self.stage_id.kanban_state

    # =====================================================
    # CREATE
    # =====================================================
    @api.model_create_multi
    def create(self, vals_list):

        for vals in vals_list:

            # -------------------------------------------------
            # AUTO GENERATE TICKET ID
            # -------------------------------------------------
            if vals.get('ticket_id', 'New') == 'New':

                vals['ticket_id'] = self.env[
                    'ir.sequence'
                ].next_by_code('helpdesk.ticket') or 'New'

            # -------------------------------------------------
            # AUTO SET DEFAULT STAGE
            # -------------------------------------------------
            if not vals.get('stage_id'):

                default_stage = self.env[
                    'helpdesk.stage'
                ].search([
                    ('default_stage', '=', True)
                ], limit=1)

                if default_stage:
                    vals['stage_id'] = default_stage.id
                    vals['kanban_state'] = default_stage.kanban_state

            # -------------------------------------------------
            # AUTO SET KANBAN STATE FROM STAGE
            # -------------------------------------------------
            elif vals.get('stage_id'):

                stage = self.env[
                    'helpdesk.stage'
                ].browse(vals['stage_id'])

                vals['kanban_state'] = stage.kanban_state

        return super(
            HelpdeskTicket,
            self
        ).create(vals_list)

    # =====================================================
    # WRITE
    # =====================================================
    def write(self, vals):

        # -------------------------------------------------
        # UPDATE KANBAN STATE WHEN STAGE CHANGES
        # -------------------------------------------------
        if vals.get('stage_id'):

            stage = self.env[
                'helpdesk.stage'
            ].browse(vals['stage_id'])

            vals['kanban_state'] = stage.kanban_state

        return super(
            HelpdeskTicket,
            self
        ).write(vals)

    # =====================================================
    # DASHBOARD DATA API
    # =====================================================
    @api.model
    def get_dashboard_data(self):

        import datetime

        uid = self.env.uid
        today = datetime.date.today()
        now = datetime.datetime.now()

        # -------------------------------------------------
        # CLOSED STAGES
        # -------------------------------------------------
        closed_stages = self.env['helpdesk.stage'].search([
            '|', '|', '|',
            ('name', 'ilike', 'closed'),
            ('name', 'ilike', 'done'),
            ('name', 'ilike', 'resolved'),
            ('name', 'ilike', 'solved')
        ])

        closed_stage_ids = closed_stages.ids

        if not closed_stage_ids:

            closed_stages = self.env[
                'helpdesk.stage'
            ].search([
                ('kanban_state', '=', 'done')
            ])

            closed_stage_ids = closed_stages.ids

        open_domain = (
            [('stage_id', 'not in', closed_stage_ids)]
            if closed_stage_ids else []
        )

        closed_domain = (
            [('stage_id', 'in', closed_stage_ids)]
            if closed_stage_ids else [('id', '=', -1)]
        )

        # -------------------------------------------------
        # MY OPEN TICKETS
        # -------------------------------------------------
        my_open_tickets = self.search([
            ('user_id', '=', uid)
        ] + open_domain)

        my_high_open_tickets = my_open_tickets.filtered(
            lambda t: t.priority == '2'
        )

        my_urgent_open_tickets = my_open_tickets.filtered(
            lambda t: t.priority == '3'
        )

        # -------------------------------------------------
        # METRICS FUNCTION
        # -------------------------------------------------
        def get_ticket_metrics(tickets_subset):

            count = len(tickets_subset)
            total_hours = 0.0

            for t in tickets_subset:

                if t.create_date:

                    delta = now - t.create_date

                    total_hours += (
                        delta.total_seconds() / 3600.0
                    )

            avg_hours = (
                round(total_hours / count)
                if count > 0 else 0
            )

            failed_count = len(
                tickets_subset.filtered(
                    lambda t: t.sla_status == 'failed'
                )
            )

            return count, avg_hours, failed_count

        (
            my_tickets_count,
            my_tickets_avg_hours,
            my_tickets_failed
        ) = get_ticket_metrics(my_open_tickets)

        (
            my_high_count,
            my_high_avg_hours,
            my_high_failed
        ) = get_ticket_metrics(my_high_open_tickets)

        (
            my_urgent_count,
            my_urgent_avg_hours,
            my_urgent_failed
        ) = get_ticket_metrics(my_urgent_open_tickets)

        # -------------------------------------------------
        # CLOSED TODAY
        # -------------------------------------------------
        start_of_today = datetime.datetime.combine(
            today,
            datetime.time.min
        )

        my_closed_today = self.search([
            ('user_id', '=', uid),
            ('write_date', '>=', start_of_today)
        ] + closed_domain)

        # -------------------------------------------------
        # CLOSED LAST 7 DAYS
        # -------------------------------------------------
        start_of_7days = datetime.datetime.combine(
            today - datetime.timedelta(days=7),
            datetime.time.min
        )

        my_closed_7days = self.search([
            ('user_id', '=', uid),
            ('write_date', '>=', start_of_7days)
        ] + closed_domain)

        closed_today_count = len(my_closed_today)
        closed_7days_count = len(my_closed_7days)

        closed_7days_avg = round(
            closed_7days_count / 7.0,
            1
        )

        # -------------------------------------------------
        # SLA RATE
        # -------------------------------------------------
        def get_sla_rate(closed_tickets):

            if not closed_tickets:
                return "/ %"

            failed_closed = len(
                closed_tickets.filtered(lambda t: t.sla_status == 'failed')
            )

            success_count = (
                len(closed_tickets) - failed_closed
            )

            rate = round(
                (success_count / len(closed_tickets)) * 100
            )

            return f"{rate}%"

        sla_today = get_sla_rate(my_closed_today)
        sla_7days = get_sla_rate(my_closed_7days)

        # -------------------------------------------------
        # TEAMS DATA
        # -------------------------------------------------
        teams_data = []

        all_teams = self.env[
            'helpdesk.team'
        ].search([])

        for team in all_teams:

            team_email = getattr(team, 'email', '')

            if not team_email:

                team_email = (
                    f"{team.name.lower().replace(' ', '-')}"
                    "@yuvmedia.odoo.com"
                )

            team_tickets = self.search([
                ('team_id', '=', team.id)
            ])

            closed_team_tickets = (
                team_tickets.filtered(
                    lambda t:
                    t.stage_id.id in closed_stage_ids
                )
                if closed_stage_ids
                else self.env['helpdesk.ticket']
            )

            open_team_tickets = (
                team_tickets.filtered(
                    lambda t:
                    t.stage_id.id not in closed_stage_ids
                )
                if closed_stage_ids
                else team_tickets
            )

            unassigned_count = len(
                open_team_tickets.filtered(
                    lambda t: not t.user_id
                )
            )

            urgent_count = len(
                open_team_tickets.filtered(
                    lambda t: t.priority == '3'
                )
            )

            failed_count = len(
                open_team_tickets.filtered(
                    lambda t: t.sla_status == 'failed'
                )
            )

            teams_data.append({
                'id': team.id,
                'name': team.name,
                'email': team_email,
                'closed_count': len(closed_team_tickets),
                'open_count': len(open_team_tickets),
                'unassigned_count': unassigned_count,
                'urgent_count': urgent_count,
                'failed_count': failed_count,
            })

        return {
            'uid': uid,

            'my_tickets': {

                'tickets': {
                    'count': my_tickets_count,
                    'avg_hours': my_tickets_avg_hours,
                    'failed': my_tickets_failed
                },

                'high_priority': {
                    'count': my_high_count,
                    'avg_hours': my_high_avg_hours,
                    'failed': my_high_failed
                },

                'urgent': {
                    'count': my_urgent_count,
                    'avg_hours': my_urgent_avg_hours,
                    'failed': my_urgent_failed
                }
            },

            'my_performance': {

                'today': {
                    'closed': closed_today_count,
                    'sla': sla_today
                },

                'last_7_days': {
                    'closed': closed_7days_avg,
                    'sla': sla_7days
                },

                'target': {
                    'closed': 1,
                    'sla': '85%'
                }
            },

            'teams': teams_data
        }