# -*- coding: utf-8 -*-
{
    'name': "YmApprovals",

    'summary': "Multi-level approval workflow with activities and chatter",

    'description': """
Approval Management System
==========================

Features:
---------
- Multi-level YmApprovals
- Sequential approval flow
- Activity scheduling for approvers
- Chatter tracking (logs)
- Product lines support
- Dynamic fields based on category
    """,

    'author': "My Company",
    'website': "https://www.yourcompany.com",

    'category': 'Tools',
    'version': '19.0.1.0',

    # ✅ REQUIRED DEPENDENCIES
    'depends': [
        'base',
        'mail',     # chatter + activities
        'hr',       # employees
        'product',  # product lines
    ],

    # ✅ LOAD ORDER IS IMPORTANT
    'data': [
        # 🔐 SECURITY FIRST
        'security/ir.model.access.csv',
        
        # 📂 MASTER DATA / MODELS VIEWS
        'views/approvers.xml',        # category first
        'views/approval.xml',   
        'views/views.xml',      # then request

    ],

    # ❌ REMOVE demo unless needed
    'demo': [],
   "assets": {
    "web.assets_backend": [
        "YmApprovals/static/src/js/chatter.js",
    ],
    "mail.assets_messaging": [
        "YmApprovals/static/src/xml/button.xml",
    ],
},

    'installable': True,
    'application': True,
    'auto_install': False,
}