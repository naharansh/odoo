/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { useService } from "@web/core/utils/hooks";
import { Message } from "@mail/core/common/message";
import { KanbanController } from "@web/views/kanban/kanban_controller";

patch(Message.prototype, {
    setup() {
        super.setup();
    },

    get hasApprovalButtons() {
        return (
            this.props.message &&
            this.props.message.model === "approval.request"
        );
    },
});

patch(KanbanController.prototype, {
    setup() {
        super.setup(...arguments);
        this.actionService = useService("action");
    },

    async createRecord() {
        if (
            this.props.resModel === "approval.category" &&
            this.props.context?.approval_dashboard
        ) {
            return this.actionService.doAction({
                type: "ir.actions.act_window",
                name: "New Request",
                res_model: "approval.request",
                views: [[false, "form"]],
                target: "current",
            });
        }
        return super.createRecord(...arguments);
    },
});
