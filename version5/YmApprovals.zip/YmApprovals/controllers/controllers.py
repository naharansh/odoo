from odoo import http
from odoo.http import request

class ApprovalRequestController(http.Controller):

    @http.route(['/approval/request/<int:res_id>/approve'], type='http', auth='user')
    def approval_request_approve(self, res_id, **kwargs):
        record = request.env['approval.request'].browse(res_id)
        if record.exists():
            record.action_approve()
        return request.redirect(f'/web#id={res_id}&model=approval.request&view_type=form')

    @http.route(['/approval/request/<int:res_id>/reject'], type='http', auth='user')
    def approval_request_reject(self, res_id, **kwargs):
        record = request.env['approval.request'].browse(res_id)
        if record.exists():
            record.action_reject()
        return request.redirect(f'/web#id={res_id}&model=approval.request&view_type=form')
