from odoo import models, fields, api
from odoo.exceptions import UserError

class ApprovalCategory(models.Model):
    _name = "approval.category"
    _description = "Approval Category"

    name = fields.Char(string="Category Name", required=True)
    approval_type = fields.Selection([
        ('procurement', 'Procurement'),
        ('finance', 'Finance'),
        ('general', 'General'),
    ], string="Approval Type", required=True)
    description = fields.Text()
    automated_sequence = fields.Boolean(
        string="Automated Sequence",
        help="Use approver sequence order automatically for this category."
    )

    document_required = fields.Selection([('none','None'),('optional','Optional'),('required','Required')], string="Document" ,default='none')
    contact_required = fields.Selection([('none','None'),('optional','Optional'),('required','Required')], string="Contact",default='none')
    date_required = fields.Selection([('none','None'),('optional','Optional'),('required','Required')], string="Date",default='none')
    period_required = fields.Selection([('none','None'),('optional','Optional'),('required','Required')], string="Period",default='none')
    product_required = fields.Selection([('none','None'),('optional','Optional'),('required','Required')], string="Product",default='none')
    quantity_required = fields.Selection([('none','None'),('optional','Optional'),('required','Required')], string="Quantity",default='none')
    amount_required = fields.Selection([('none','None'),('optional','Optional'),('required','Required')], string="Amount",default='none')
    reference_required = fields.Selection([('none','None'),('optional','Optional'),('required','Required')], string="Reference",default='none')
    location_required = fields.Selection([('none','None'),('optional','Optional'),('required','Required')], string="Location",default='none')

    approver_line_ids = fields.One2many('approval.approver', 'category_id', string="Approvers")
    min_approvals = fields.Integer(string="Minimum Approval Count")
    request_ids = fields.One2many('approval.request', 'category_id', string="Requests")
    request_count = fields.Integer(compute='_compute_request_count', string="Request Count")
    to_review_count = fields.Integer(compute='_compute_to_review_count', string="To Review")

    @api.depends('request_ids')
    def _compute_request_count(self):
        for rec in self:
            rec.request_count = len(rec.request_ids)

    @api.depends('request_ids.state')
    def _compute_to_review_count(self):
        for rec in self:
            rec.to_review_count = len(rec.request_ids.filtered(lambda request: request.state == 'submitted'))

    def action_new_request(self):
        employee = self.env['hr.employee'].search(
            [('user_id', '=', self.env.uid)], limit=1
        )
        if not employee:
            raise UserError(
                "No employee record is linked to your user account.\n"
                "Please go to Employees → select your employee → "
                "HR Settings tab → set 'Related User' to your account."
            )
        return {
            'type': 'ir.actions.act_window',
            'name': 'New Request',
            'res_model': 'approval.request',
            'view_mode': 'form',
            'target': 'current',
            'context': {
                'default_category_id': self.id,
                'default_requester_id': self.env.uid,  # ✅ res.users ID, not employee.id
                'default_employee_id': employee.id,    # ✅ pass employee separately if needed
            }
        }

    def action_to_review(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'To Review',
            'res_model': 'approval.request',
            'view_mode': 'list,form',
            'domain': [
                ('category_id', '=', self.id),
                ('state', '=', 'submitted'),
            ],
        }


class ApprovalApprover(models.Model):
    _name = "approval.approver"
    _description = "Approval Approver"

    category_id = fields.Many2one('approval.category', string="Category")
    employee_id = fields.Many2one('hr.employee', string="Employee", required=True)
    sequence = fields.Integer(string="Sequence", default=1)
    is_manager = fields.Boolean(string="Is Manager")
    company_id = fields.Many2one(
        'res.company', string="Company",
        default=lambda self: self.env.company,
    )
