from odoo import models, fields, api, _
from odoo.exceptions import UserError
import logging

_logger = logging.getLogger(__name__)


# -------------------------------
# APPROVER LINE
# -------------------------------
class ApprovalRequestLine(models.Model):
    _name = "approval.request.line"
    _description = "Approval Request Line"

    request_id = fields.Many2one(
        'approval.request',
        string="Request",
        required=True,
        ondelete="cascade"
    )

    approver_id = fields.Many2one(
        'hr.employee',
        string="Approver",
        required=True
    )

    user_id = fields.Many2one(
        'res.users',
        related='approver_id.user_id',
        string="User",
        store=True
    )

    sequence = fields.Integer(default=1)

    status = fields.Selection([
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
    ], default='pending')

    decision_date = fields.Datetime(
        string="Decision Date",
        readonly=True
    )

    comment = fields.Text(string="Comment")

    can_approve = fields.Boolean(
        compute='_compute_can_approve',
        string="Can Approve"
    )

    @api.depends('status', 'approver_id', 'approver_id.user_id')
    def _compute_can_approve(self):
        user = self.env.user
        for rec in self:
            if rec.status != 'pending':
                rec.can_approve = False
            else:
                rec.can_approve = (rec.approver_id.user_id == user)

    def write(self, vals):
        protected = {'status', 'comment'}
        if protected & set(vals.keys()):
            for rec in self:
                if self.env.context.get('bypass_approver_check'):
                    continue
                if rec.approver_id.user_id != self.env.user:
                    raise UserError(_(
                        "You are not allowed to modify another approver's approval data."
                    ))
        return super().write(vals)

    def action_approve(self):
        for rec in self:
            if rec.status != 'pending':
                continue

            user = self.env.user

            if rec.approver_id.user_id != user:
                raise UserError(_("You are not allowed to approve this request."))

            rec.write({
                'status': 'approved',
                'decision_date': fields.Datetime.now(),
            })

            request = rec.request_id
            request.message_post(
                body=_("✅ %(approver)s approved — %(comment)s") % {
                    'approver': rec.approver_id.name,
                    'comment': rec.comment or _("No comment"),
                },
                author_id=user.partner_id.id
            )
            request._activity_feedback_safe()

            next_line = request.approver_line_ids.filtered(
                lambda l: l.status == 'pending'
            ).sorted(key=lambda l: l.sequence)[:1]

            if next_line and next_line.approver_id.user_id:
                request.activity_schedule(
                    'mail.mail_activity_data_todo',
                    user_id=next_line.approver_id.user_id.id,
                    note=_("Your approval is required.")
                )
            else:
                request.with_context(from_approval_action=True).write({'state': 'approved'})
                request.message_post(body=_("🎉 Request fully approved."))

    def action_reject(self):
        for rec in self:
            if rec.status != 'pending':
                continue

            user = self.env.user

            if rec.approver_id.user_id != user:
                raise UserError(_("You are not allowed to reject this request."))

            rec.write({
                'status': 'rejected',
                'decision_date': fields.Datetime.now(),
            })

            request = rec.request_id
            request.with_context(from_approval_action=True).write({'state': 'rejected'})
            request.message_post(
                body=_("❌ %(approver)s rejected — %(comment)s") % {
                    'approver': rec.approver_id.name,
                    'comment': rec.comment or _("No comment"),
                },
                author_id=user.partner_id.id
            )
            request._activity_feedback_safe()


# -------------------------------
# MAIN REQUEST
# -------------------------------
class ApprovalRequest(models.Model):
    _name = "approval.request"
    _description = "Approval Request"
    _inherit = ['mail.thread', 'mail.activity.mixin']

    name = fields.Char(required=True, tracking=True)

    category_id = fields.Many2one(
        'approval.category',
        required=True,
        tracking=True
    )

    requester_id = fields.Many2one(
        'res.users',
        string="Requested By",
        default=lambda self: self.env.user,
        tracking=True
    )

    request_date = fields.Datetime(
        default=fields.Datetime.now,
        tracking=True
    )

    state = fields.Selection([
        ('draft', 'To Submit'),
        ('submitted', 'Submitted'),
        ('approved', 'Approved'),
        ('rejected', 'Refused'),
    ], default='draft', tracking=True, string="Status", group_expand='_read_group_state')

    description = fields.Text()

    approver_line_ids = fields.One2many(
        'approval.request.line',
        'request_id',
        string="Approvers"
    )

    primary_approver_id = fields.Many2one(
        'hr.employee',
        compute='_compute_primary_approver',
        string="Approver"
    )

    product_line_ids = fields.One2many(
        'approval.request.product',
        'request_id',
        string="Products"
    )

    # ── Current user approval state ──
    current_user_line_id = fields.Many2one(
        'approval.request.line',
        compute='_compute_current_user_line',
        string="My Approval Line"
    )

    show_approve_button = fields.Boolean(
        compute='_compute_current_user_line'
    )

    @api.model
    def _read_group_state(self, states, domain, order=None):
        return [key for key, label in self._fields['state'].selection]

    @api.depends('approver_line_ids.sequence', 'approver_line_ids.approver_id')
    def _compute_primary_approver(self):
        for rec in self:
            first_line = rec.approver_line_ids.sorted(key=lambda line: line.sequence)[:1]
            rec.primary_approver_id = first_line.approver_id if first_line else False

    @api.depends('approver_line_ids.status', 'approver_line_ids.approver_id',
                 'approver_line_ids.approver_id.user_id', 'state')
    def _compute_current_user_line(self):
        user = self.env.user
        for rec in self:
            if rec.state != 'submitted':
                rec.current_user_line_id = False
                rec.show_approve_button = False
                continue

            line = rec.approver_line_ids.filtered(
                lambda l: l.status == 'pending' and l.approver_id.user_id == user
            ).sorted(key=lambda l: l.sequence)[:1]

            rec.current_user_line_id = line[:1] if line else False
            rec.show_approve_button = bool(line)

    # ── Related fields from category (drive show/hide on request form) ──
    document_required  = fields.Selection(related='category_id.document_required',  string="Document Required")
    contact_required   = fields.Selection(related='category_id.contact_required',   string="Contact Required")
    date_required      = fields.Selection(related='category_id.date_required',      string="Date Required")
    period_required    = fields.Selection(related='category_id.period_required',    string="Period Required")
    product_required   = fields.Selection(related='category_id.product_required',   string="Product Required")
    quantity_required  = fields.Selection(related='category_id.quantity_required',  string="Quantity Required")
    amount_required    = fields.Selection(related='category_id.amount_required',    string="Amount Required")
    reference_required = fields.Selection(related='category_id.reference_required', string="Reference Required")
    location_required  = fields.Selection(related='category_id.location_required',  string="Location Required")

    # ── Actual request data fields ──
    contact_id   = fields.Many2one('res.partner', string="Contact", tracking=True)
    date         = fields.Date(string="Date", tracking=True)
    date_start   = fields.Date(string="Period Start", tracking=True)
    date_end     = fields.Date(string="Period End", tracking=True)
    amount       = fields.Float(string="Amount", tracking=True)
    reference    = fields.Char(string="Reference", tracking=True)
    location     = fields.Char(string="Location", tracking=True)
    document_ids = fields.Many2many(
        'ir.attachment',
        string="Documents",
        tracking=True
    )

    # -------------------------------
    # SUBMIT
    # -------------------------------
    def action_submit(self):
        for rec in self:
            # if not rec.approver_line_ids:
            #     raise UserError(_("Please add at least one approver before submitting."))

            # Validate required fields from category
            rec._check_required_fields()

            rec.with_context(from_approval_action=True).write({'state': 'submitted'})
            rec.message_post(body=_("📨 Request submitted for approval."))

            first = rec.approver_line_ids.sorted(key=lambda l: l.sequence)[:1]
            if first and first.approver_id.user_id:
                rec.activity_schedule(
                    'mail.mail_activity_data_todo',
                    user_id=first.approver_id.user_id.id,
                    note=_("Please approve this request.")
                )

    def _check_required_fields(self):
        """Validate category-required fields before submission."""
        for rec in self:
            errors = []
            if rec.contact_required == 'required' and not rec.contact_id:
                errors.append(_("Contact"))
            if rec.date_required == 'required' and not rec.date:
                errors.append(_("Date"))
            if rec.period_required == 'required' and (not rec.date_start or not rec.date_end):
                errors.append(_("Period (Start and End)"))
            if rec.amount_required == 'required' and not rec.amount:
                errors.append(_("Amount"))
            if rec.reference_required == 'required' and not rec.reference:
                errors.append(_("Reference"))
            if rec.location_required == 'required' and not rec.location:
                errors.append(_("Location"))
            if rec.document_required == 'required' and not rec.document_ids:
                errors.append(_("Documents"))
            if rec.product_required == 'required' and not rec.product_line_ids:
                errors.append(_("Products"))
            if errors:
                raise UserError(
                    _("The following required fields are missing:\n• %s") % "\n• ".join(errors)
                )

    # -------------------------------
    # REFUSE / RESET
    # -------------------------------
    def action_refuse(self):
        for rec in self:
            if rec.state != 'submitted':
                raise UserError(_("Only submitted requests can be refused."))
            line = rec.current_user_line_id
            if not line:
                raise UserError(_("No pending approval line found for you."))
            line.action_reject()

    def action_reset_to_draft(self):
        for rec in self:
            if rec.state not in ('rejected',):
                raise UserError(_("Only rejected requests can be reset to draft."))
            # Reset ALL approver lines back to pending for clean resubmission
            rec.approver_line_ids.with_context(bypass_approver_check=True).write({'status': 'pending'})
            rec.with_context(from_approval_action=True).write({'state': 'draft'})
            rec.message_post(body=_("🔄 Request reset to draft."))

    # -------------------------------
    # APPROVE / REJECT (header/banner buttons)
    # -------------------------------
    def action_approve_request(self):
        for rec in self:
            if not rec.current_user_line_id:
                raise UserError(_("No pending approval line found for you."))
            rec.current_user_line_id.action_approve()

    def action_reject_request(self):
        for rec in self:
            if not rec.current_user_line_id:
                raise UserError(_("No pending approval line found for you."))
            rec.current_user_line_id.action_reject()

    # -------------------------------
    # ADMIN SHORTCUTS
    # -------------------------------
    def action_admin_approve(self):
        if not self.env.user.has_group('base.group_system'):
            raise UserError(_("Only administrators can perform this action."))
        for rec in self:
            if rec.state != 'submitted':
                raise UserError(_("Only submitted requests can be approved."))
            rec.approver_line_ids.with_context(bypass_approver_check=True).filtered(
                lambda l: l.status == 'pending'
            ).write({'status': 'approved', 'decision_date': fields.Datetime.now()})
            rec.with_context(from_approval_action=True).write({'state': 'approved'})
            rec.message_post(body=_("✅ Approved by Administrator."))
            rec._activity_feedback_safe()

    def action_admin_reject(self):
        if not self.env.user.has_group('base.group_system'):
            raise UserError(_("Only administrators can perform this action."))
        for rec in self:
            if rec.state != 'submitted':
                raise UserError(_("Only submitted requests can be rejected."))
            rec.approver_line_ids.with_context(bypass_approver_check=True).filtered(
                lambda l: l.status == 'pending'
            ).write({'status': 'rejected', 'decision_date': fields.Datetime.now()})
            rec.with_context(from_approval_action=True).write({'state': 'rejected'})
            rec.message_post(body=_("❌ Rejected by Administrator."))
            rec._activity_feedback_safe()

    # -------------------------------
    # SAFE ACTIVITY FEEDBACK
    # -------------------------------
    def _activity_feedback_safe(self):
        """Mark current todo activities as done WITHOUT triggering auto-approve."""
        ActivityModel = self.env['mail.activity']
        for rec in self:
            activities = ActivityModel.search([
                ('res_model', '=', 'approval.request'),
                ('res_id', '=', rec.id),
                ('activity_type_id', '=',
                 self.env.ref('mail.mail_activity_data_todo').id),
            ])
            activities.action_feedback(feedback='Done')

    # -------------------------------
    # BLOCK DIRECT STATE CHANGE
    # -------------------------------
    def write(self, vals):
        if 'state' in vals and not self.env.context.get('from_approval_action'):
            raise UserError(_(
                "State cannot be changed manually. "
                "Use the Submit / Approve / Reject buttons."
            ))
        return super().write(vals)

    # -------------------------------
    # AUTO LOAD APPROVERS FROM CATEGORY
    # -------------------------------
    @api.onchange('category_id')
    def _onchange_category_id(self):
        if self.category_id:
            self.approver_line_ids = [(5, 0, 0)] + [(0, 0, {
                'approver_id': a.employee_id.id,
                'sequence': a.sequence,
            }) for a in self.category_id.approver_line_ids]
        else:
            self.approver_line_ids = [(5, 0, 0)]


# -------------------------------
# PRODUCT LINE
# -------------------------------
class ApprovalRequestProduct(models.Model):
    _name = "approval.request.product"
    _description = "Approval Request Product Line"

    request_id = fields.Many2one(
        'approval.request',
        ondelete="cascade"
    )
    product_id = fields.Many2one('product.product', required=True)
    description = fields.Char()
    quantity = fields.Float(default=1.0)
    unit_price = fields.Float()

    subtotal = fields.Float(
        compute="_compute_subtotal",
        store=True
    )

    @api.depends('quantity', 'unit_price')
    def _compute_subtotal(self):
        for rec in self:
            rec.subtotal = rec.quantity * rec.unit_price

    @api.onchange('product_id')
    def _onchange_product_id(self):
        if self.product_id:
            self.description = self.product_id.name
            self.unit_price = self.product_id.lst_price
