from odoo import models, fields, api
import requests

class FacebookAccount(models.Model):
    _name = 'crm.facebook.account'
    _description = 'Facebook Account'

    name = fields.Char(required=True)
    app_id = fields.Char()
    app_secret = fields.Char()
    access_token = fields.Char(string="Access Token")
    page_id = fields.Char(string="Page ID")
    connection_valid = fields.Boolean(string="Connection Valid", default=False)

    def _fb_request(self, endpoint, params=None):
        """Generic Facebook API request with stored access_token"""
        self.ensure_one()
        token = self.access_token or self.env['ir.config_parameter'].sudo().get_param('facebook_integration.access_token')
        if not token:
            raise ValueError("⚠️ No access token set in this account or system parameters.")

        url = f"https://graph.facebook.com/v19.0/{endpoint}"
        params = params or {}
        params['access_token'] = token

        res = requests.get(url, params=params, timeout=10)
        if res.status_code != 200:
            raise ValueError(f"Facebook API error {res.status_code}: {res.text}")
        return res.json()

    def set_system_credentials(self):
        """Save access_token and page_id into Odoo system parameters"""
        self.ensure_one()
        if not self.access_token:
            raise ValueError("⚠️ No access token set in this account.")
        if not self.page_id:
            raise ValueError("⚠️ No page_id set in this account.")

        config = self.env['ir.config_parameter'].sudo()
        config.set_param('facebook_integration.access_token', self.access_token)
        config.set_param('facebook_integration.page_id', self.page_id)

    def action_test_connection(self):
        """Test connection and store credentials"""
        self.ensure_one()
        self.set_system_credentials()

        data = self._fb_request("me")
        self.connection_valid = True

        return {
            'type': 'ir.actions.client',
            'tag': 'display_notification',
            'params': {
                'title': 'Success',
                'message': f"Connected as {data.get('name')} (ID {data.get('id')})",
                'type': 'success',
                'sticky': False,
                'next': {
                    'type': 'ir.actions.client',
                    'tag': 'soft_reload',
                }
            },
        }

    def action_sync_leadforms(self):
        """Fetch lead forms from Facebook and open the lead forms list"""
        self.ensure_one()
        return self.env['crm.facebook.campaign'].action_fetch_leadforms()
