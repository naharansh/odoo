from odoo import models, fields
import requests

class FacebookCampaign(models.Model):
    _name = 'crm.facebook.campaign'
    _description = 'Facebook Campaign'

    name = fields.Char(string="Campaign Name")
    fb_form_id = fields.Char(string="Facebook Form ID")
    page_id = fields.Char(string="Page ID")
    status = fields.Selection(
        [('active', 'Active'), ('paused', 'Paused')],
        string="Status"
    )

    leadform_ids = fields.One2many(
        'crm.facebook.leadform',
        'campaign_id',
        string="Lead Forms"
    )

    def action_fetch_leadforms(self):
        """Fetch lead forms for the configured page and open lead forms list view"""
        ICP = self.env['ir.config_parameter'].sudo()
        page_id = ICP.get_param('facebook_integration.page_id')
        access_token = ICP.get_param('facebook_integration.access_token')

        if not page_id or not access_token:
            raise ValueError("⚠️ Missing page_id or access_token in system parameters.")

        url = f"https://graph.facebook.com/v19.0/{page_id}/leadgen_forms"
        resp = requests.get(url, params={
            'access_token': access_token,
            'fields': 'id,name,status,leads_count'
        }, timeout=15).json()

        if 'error' in resp:
            raise ValueError(f"❌ Error: {resp['error']}")

        # Find the facebook account record to link it
        account = self.env['crm.facebook.account'].search([('page_id', '=', page_id)], limit=1)

        for form in resp.get('data', []):
            campaign = self.search([('fb_form_id', '=', form['id'])])
            if not campaign:
                campaign = self.create({
                    'name': form.get('name'),
                    'fb_form_id': form['id'],
                    'page_id': page_id,
                    'status': 'active',
                })

            leadform_model = self.env['crm.facebook.leadform']
            leadform = leadform_model.search([('form_id', '=', form['id'])])
            if not leadform:
                leadform_model.create({
                    'name': form.get('name'),
                    'form_id': form['id'],
                    'campaign_id': campaign.id,
                    'account_id': account.id if account else False,
                    'leads_count': form.get('leads_count', 0),
                })
            else:
                leadform.write({
                    'name': form.get('name'),
                    'leads_count': form.get('leads_count', 0),
                    'campaign_id': campaign.id,
                    'account_id': account.id if account else False,
                })

        return {
            'type': 'ir.actions.act_window',
            'name': 'Lead Forms',
            'res_model': 'crm.facebook.leadform',
            'view_mode': 'list,form',
            'views': [(False, 'list'), (False, 'form')],
            'target': 'current',
            'context': {'create': False},
        }

    def action_view_leadforms(self):
        """Open lead forms linked to this campaign"""
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Lead Forms',
            'res_model': 'crm.facebook.leadform',
            'view_mode': 'list,form',
            'domain': [('campaign_id', '=', self.id)],
            'context': {'default_campaign_id': self.id},
        }


class FacebookLeadForm(models.Model):
    _name = 'crm.facebook.leadform'
    _description = 'Facebook Lead Form'

    name = fields.Char(required=True)
    form_id = fields.Char(string="Form ID", required=True)
    campaign_id = fields.Many2one('crm.facebook.campaign', string="Campaign")
    account_id = fields.Many2one('crm.facebook.account', string="Facebook Account")
    leads_count = fields.Integer(string="Leads Count")

    def action_fetch_leads(self):
        """Fetch leads for this form and create crm.lead records, then open leads view"""
        self.ensure_one()
        ICP = self.env['ir.config_parameter'].sudo()
        access_token = ICP.get_param('facebook_integration.access_token')

        if not access_token:
            raise ValueError("⚠️ Missing access_token in system parameters.")

        url = f"https://graph.facebook.com/v19.0/{self.form_id}/leads"
        resp = requests.get(url, params={
            'access_token': access_token,
            'fields': 'id,created_time,field_data'
        }, timeout=15).json()

        if 'error' in resp:
            raise ValueError(f"❌ Error: {resp['error']}")

        crm_lead_env = self.env['crm.lead']
        for fb_lead in resp.get('data', []):
            lead_id = fb_lead['id']
            # Check if lead already exists
            existing_lead = crm_lead_env.search([('fb_lead_id', '=', lead_id)], limit=1)
            if existing_lead:
                continue
            
            # Map field_data
            created_time_str = fb_lead.get('created_time')
            if created_time_str:
                created_time_str = created_time_str[:19].replace('T', ' ')

            lead_data = {
                'name': f"{self.name} - {lead_id}",
                'fb_lead_id': lead_id,
                'fb_form_id': self.id,
                'type': 'lead',
                'user_id': False,
                'description': f"Created Time: {fb_lead.get('created_time')}\n",
            }

            for field in fb_lead.get('field_data', []):
                name = field['name']
                val = field['values'][0] if field.get('values') else ''
                
                # Map standard fields if possible
                if name == 'full_name':
                    lead_data['contact_name'] = val
                elif name == 'email':
                    lead_data['email_from'] = val
                elif name == 'phone_number':
                    lead_data['phone'] = val
                
                lead_data['description'] += f"{name}: {val}\n"

            crm_lead_env.create(lead_data)

        # Return action to view standard crm leads filtered by this form
        return {
            'type': 'ir.actions.act_window',
            'name': f"Leads: {self.name}",
            'res_model': 'crm.lead',
            'view_mode': 'kanban,list,form',
            'domain': [('fb_form_id', '=', self.id)],
            'context': {'default_fb_form_id': self.id, 'default_type': 'lead'},
        }

class CrmLead(models.Model):
    _inherit = 'crm.lead'

    fb_lead_id = fields.Char(string="Facebook Lead ID", index=True)
    fb_form_id = fields.Many2one('crm.facebook.leadform', string="Facebook Lead Form")
    fb_campaign_id = fields.Many2one(related='fb_form_id.campaign_id', string="Facebook Campaign", store=True)
    raw_data = fields.Text(string="Raw Data (Facebook)", help="Raw data from Facebook LeadGen webhook/API")
